<?php
// App\Scopes\OutletScope.php

namespace App\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;

class OutletScope implements Scope
{
    public function apply(Builder $builder, Model $model)
    {
        if (!Auth::check()) return;

        $user = Auth::user();

        if (method_exists($user, 'isSuperAdmin') && $user->isSuperAdmin()) return;

        if (empty($user->current_outlet_id)) return;

        if (!Schema::hasColumn($model->getTable(), 'outlet_id')) return;

        $builder->where(
            $model->qualifyColumn('outlet_id'),
            $user->current_outlet_id
        );
    }
}
